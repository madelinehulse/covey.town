import Player from "../types/Player";
import CheckersController from "./CheckersController";

export default class CheckersStore {
    private static _instance: CheckersStore;

  private _games: CheckersController[] = [];

  static getInstance(): CheckersStore {
    if (CheckersStore._instance === undefined) {
      CheckersStore._instance = new CheckersStore();
    }
    return CheckersStore._instance;
  }

  //Game ID from the game controller
  getControllerForGame(gameID: string): CheckersController | undefined {
    return this._games.find(town => town.gameID === gameID);
  }

  //TODO: Create Game
  createGame(player1: Player, player2:Player) {
    const newGame = new CheckersController(player1, player2);
    this._games.push(newGame);
    return newGame;
  }

  //TODO: Update Game
  updateGame(gameID:string, fromRow:number,fromCol:number,toRow:number,toCol:number) {
    const existingGame = this.getControllerForGame(gameID);
    if(existingGame) {
      // I want to do the move thing
      existingGame.movePiece(fromRow, fromCol, toRow, toCol);
      // So this thing doesn't return anything, but should we make it such that it does return something?
    }
    // Maybe return false as the CoveyTownsStroe has done?
    //But then existing move thing should return true right?
  }

  //TODO: Delete Game
  deleteGame(gameID: string) {
    const existingGame = this.getControllerForGame(gameID);

    if (existingGame && existingGame.isGameOver()) {
      this._games = this._games.filter(game => game !== existingGame);
      //Would we need something like this?
      //existingTown.disconnectAllPlayers();
      //return true;
    }
    //return false;
  }
}